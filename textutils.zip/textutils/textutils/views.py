# I Have created this file - Hammad
from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    #paradic = {'name':'hammad', 'place':'karachi'}
    return render(request,'index.html')
#     return HttpResponse('''<html>
#     <title>
#         Hammad's Text Utils
#     </title>
# <body>
#     <ul>
#         <H1>Welcome to navigation Menu </H1>
#         <li><a href="http://127.0.0.1:8000/capitalizefirst">Capitalize First</a></li>
#         <li><a href="http://127.0.0.1:8000/removepunctuation">Remove Punctuation</a></li>
#         <li><a href="http://127.0.0.1:8000/newlineremover">Newline Remover</a></li>
#         <li><a href="http://127.0.0.1:8000/spaceremover">Space Remover</a></li>
#         <li><a href="http://127.0.0.1:8000/charactercount">Character Count</a></li>
#     </ul>
# </body>
# </html>''')
def analyze(request):
    analyze = ""
    text = request.POST.get('textbox','default')
    removepunc = request.POST.get('rp','off')
    capi = request.POST.get('cf','off')
    newrem = request.POST.get('nr','off')
    spcrem = request.POST.get('sr','off')
    charcou = request.POST.get('cc','off')
    if removepunc == 'on':
       analyze = ""
       punclis = '''!"#$%&'()*+, -./:;<=>?@[\]^_`{|}~'''
       for char in text:
          if char not in punclis:
            analyze = analyze + char
       dispp = {'purpose': 'Remove Punctuation', 'analyzed_text': analyze}
       text = analyze
       # return render(request, 'analyze.html', dispp)


    if capi == 'on':
        analyze = ""
        for char in text:
            analyze = analyze + char.upper()
        dispp = {'purpose': 'Capitalize All', 'analyzed_text': analyze}
        text = analyze
        # return render(request, 'analyze.html', dispp)


    if newrem == 'on':
        analyze = ""
        for char in text:
            if char not in "\n" and char not in "\r":
                analyze = analyze + char
        dispp = {'purpose': 'NewLine Remover', 'analyzed_text': analyze}
        text = analyze
        # return render(request, 'analyze.html', dispp)


    if spcrem == 'on':
        analyze = ""
        for index, char in enumerate(text):
            if not (text[index] == ' ' and text[index+1] == ' '):
              analyze = analyze + char
        dispp = {'purpose':'Space Remover','analyzed_text':analyze}
        text = analyze
        # return render(request,'analyze.html',dispp)


    if charcou == 'on':
        analyze = 0
        for char in text:
            if char not in ' ':
               analyze = analyze + len(char)
        dispp = {'purpose':'Character Count','analyzed_text':analyze}
        text = analyze
        # return render(request,'analyze.html',dispp)

    if spcrem == 'on' or charcou == 'on' or newrem == 'on' or removepunc == 'on' or capi == 'on':
        return render(request, 'analyze.html', dispp)

    else:
        return HttpResponse('Error')


# def spaceremove(request):
#     return HttpResponse('Space Remover <br> <a href="http://127.0.0.1:8000">BACK</a>')
# def charcount(request):
#     return HttpResponse('char count <br> <a href="http://127.0.0.1:8000">BACK</a>')
# def newremove(request):
#     return HttpResponse('newline remove <br> <a href="http://127.0.0.1:8000">BACK</a>')
# def removepunc(request):
#     #get the text
#     text = request.GET.get('textbox','default')
#     print(text)
#     #analyze the text
#     return HttpResponse('remove punc <br> <a href="http://127.0.0.1:8000">BACK</a>')
# def capfirst(request):
#     return HttpResponse('Cap First <br> <a href="http://127.0.0.1:8000">BACK</a>')
# def exercise1(request):
#     file=open("1.txt",'r+')
#     return HttpResponse(file.read())